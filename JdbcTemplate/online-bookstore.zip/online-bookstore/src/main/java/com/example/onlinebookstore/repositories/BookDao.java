package com.example.onlinebookstore.repositories;

import com.example.onlinebookstore.entities.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class BookDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Book> findAll(){
        String sql = "SELECT * FROM book";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Book.class));
    }

    public Book findById(Long id){
        String sql = "SELECT * FROM book WHERE id = ?";
        return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(Book.class), id);
    }

    public int save (Book book){
        String sql = "INSERT INTO book (title, author) VALUES (?, ?)";
        return jdbcTemplate.update(sql, book.getTitle(), book.getAuthor());
    }

    public int update (Book book){
        String sql = "UPDATE book SET title = ?, author = ? WHERE id = ?";
        return jdbcTemplate.update(sql, book.getTitle(), book.getAuthor(), book.getId());
    }

    public int deleteById (Long id){
        String sql = "DELETE FROM book WHERE id = ?";
        return jdbcTemplate.update(sql, id);
    }
}
