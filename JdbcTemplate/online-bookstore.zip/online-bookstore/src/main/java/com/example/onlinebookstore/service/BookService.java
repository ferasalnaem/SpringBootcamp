package com.example.onlinebookstore.service;

import com.example.onlinebookstore.entities.Book;
import com.example.onlinebookstore.repositories.BookDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    private final BookDao bookDao;

    @Autowired
    public BookService(BookDao bookDao){
        this.bookDao = bookDao;
    }

    public int saveBook(Book book){
        return bookDao.save(book);
    }

    public List<Book> findAllBooks(){
        return bookDao.findAll();
    }

    public Book findBookById(Long id){
        return bookDao.findById(id);
    }

    public int deleteBook(Long id){
        return bookDao.deleteById(id);
    }

}
