package com.example.onlinebookstore.config;

import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import io.jsonwebtoken.SignatureException;

public class JwtRequestFilter extends OncePerRequestFilter {

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
        throws ServletException, IOException {

        final String authorizationHeader = request.getHeader("Authorization");

        String username = null;
        String jwtToken = null;

        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            jwtToken = authorizationHeader.substring(7); //Remove "Bearer " prefix
            try {
                username = jwtTokenUtil.getUsername(jwtToken);
            } catch (Exception e) {
                //We can log the exception
            }
        }

        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            if (!jwtTokenUtil.isTokenExpired(jwtToken)) {
                UserDetails userDetails = userDetailsService.loadUserByUsername(username);

                //validate token
                try {
                    Claims claims = jwtTokenUtil.getClaims(jwtToken);
                    if (userDetails.getUsername().equals(claims.getSubject())) {
                        Authentication authentication = jwtTokenUtil.getAuthentication(jwtToken, userDetails);
                        SecurityContextHolder.getContext().setAuthentication(authentication);
                    }
                } catch (SignatureException e) {
                    //We can handle the case when token signature is invalid
                }
            }
        }

        chain.doFilter(request, response);
    }
}
