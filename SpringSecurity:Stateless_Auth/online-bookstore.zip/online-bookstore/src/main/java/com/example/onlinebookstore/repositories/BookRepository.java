package com.example.onlinebookstore.repositories;

import com.example.onlinebookstore.entities.Book;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
    List<Book> findByAuthor(String author);

    @Query(value = "SELECT * FROM books WHERE title LIKE %?1%", nativeQuery = true)
    List<Book> findBooksByTitleContainingNative(String title);

    Page<Book> findAll(Pageable pageable);

}
