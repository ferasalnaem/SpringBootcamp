package com.example.onlinebookstore.config;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class AppConfig {

    @Value("${server.port}")
    private int serverPort;

    @Autowired
    private Environment environment;

    @Bean
    public String welcomeMessage(){return "Welcome to the Online Bookstore! " + "running on port: " + serverPort + " Logging level: " +
            environment.getProperty("logging.level.root"); }

    @PostConstruct
    public void init() {System.out.println("Initializing the Online Bookstore application...");}

    @PreDestroy
    public void cleanup() {System.out.println("Cleaning up resources before shutting down...");}
}
